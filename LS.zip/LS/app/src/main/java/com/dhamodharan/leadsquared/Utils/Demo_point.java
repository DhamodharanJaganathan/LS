package com.dhamodharan.leadsquared.Utils;

public class Demo_point {

  public static String value ="google-news-in";

}
